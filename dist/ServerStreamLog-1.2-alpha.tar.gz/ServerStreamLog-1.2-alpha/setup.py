#!/usr/bin/env python

from distutils.core import setup

setup(name='ServerStreamLog',
      version='1.2-alpha',
      description='App to make log streaming',
      author='Jose de Soto',
      author_email='josedesoto@gmail.com',
      url='',
      packages=['.', 'lib'],
     )
